//مهرسا احمدی 40223002
#include <stdio.h>
#include <stdlib.h>

struct time 
{
    int min;
    int sec;
};

struct runner
{
    char first_name[20];
    char last_name[20];
    char ID[20];
    struct time *record;
    struct time running_time;
};

int main()
{
    int n; //the numbers of runners

    printf("Enter the numbers of runners : \n");
    scanf("%d", &n);

    struct runner array[n];

    for(int i = 0 ; i < n ; i++)
    {
        printf("Enter the name of runner %d:\n", i+1);
        scanf("%s",array[i].first_name);
        printf("Enter the last name of runner %d:\n", i+1);
        scanf("%s",array[i].last_name);
        printf("Enter the ID of runner %d:\n", i+1);
        scanf("%s",array[i].ID);
        printf("Enter the best record of runner(min:sec) %d:\n", i+1);
        array[i].record=(struct time *)malloc(sizeof(struct time));
        scanf("%d:%d",&array[i].record->min, &array[i].record->sec);
        printf("Enter the runnig time of runner %d in the competition(min:sec):\n", i+1);
        scanf("%d:%d",&array[i].running_time.min, &array[i].running_time.sec);
    }


    int winner = 0;
    for(int i = 1 ; i < n ; i++)
    {
        if( (array[i].running_time.min < array[winner].running_time.min) ||
         ( ( array[i].running_time.min ==  array[winner].running_time.min ) && ( array[i].running_time.sec < array[winner].running_time.sec ) ) )

             winner = i;
    }

    printf("The winner is : %s", array[winner].first_name);
    printf("\t%s", array[winner].last_name);

   
    
    
    if ( (array[winner].running_time.min < array[winner].record->min) || 
    ( ( array[winner].running_time.min == array[winner].record->min ) && ( array[winner].running_time.sec < array[winner].record->sec) ) ) 
        printf("\nThe winner has broken his/her own record");
        

    else
        printf("\nThe winner has not broken his/her own record .");



    int count = 0;
    
    for(int i = 0 ; i < n ; i++)
    {
        if ( ( array[winner].running_time.min < array[i].record->min ) || 
        ( ( array[winner].running_time.min == array[i].record->min ) && ( array[winner].running_time.sec < array[i].record->sec ) ) )
            count = 1;

        else if( (array[i].running_time.min < array[winner].running_time.min) ||
        ( ( array[i].running_time.min ==  array[winner].running_time.min ) && ( array[i].running_time.sec < array[winner].running_time.sec ) ) )
            count=2;
    }

    if ( count == 1 || count == 2 )
    printf("\nThe winner has broken all runner's best records.");
    
    else
    printf("\nThe runner has not broken other runner's best records.");


        for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++) 
        {
            if (array[j].running_time.min > array[j + 1].running_time.min ||
                (array[j].running_time.min == array[j + 1].running_time.min &&
                 array[j].running_time.sec > array[j + 1].running_time.sec))
            {
                
                struct runner temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }


     printf("\n%-20s%-20s","first name","last name");
     printf("%-10s%-20s%-10s","ID","record","running time");
     printf("\n");
    
    
    for (int i = 0; i < n; i++) 
    {
        printf("%-20s%-20s%-10s%-2d:%-20d%-2d:%-20d\n",
               array[i].first_name, array[i].last_name,array[i].ID,
               array[i].record->min, array[i].record->sec,
               array[i].running_time.min, array[i].running_time.sec);
    }    






    return 0;
}